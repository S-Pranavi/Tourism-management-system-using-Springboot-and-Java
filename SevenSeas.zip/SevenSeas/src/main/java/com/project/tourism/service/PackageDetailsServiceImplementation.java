package com.project.tourism.service;


import java.time.LocalDate;
//import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.tourism.model.Tour;
import com.project.tourism.repository.PackageRepository;


@Service
public class PackageDetailsServiceImplementation implements PackageDetailsService{


	@Autowired
	private PackageRepository packageDetailsRepository;

	 @Autowired
	   private PricingStrategy offSeasonPricingStrategy;
	    
	    @Autowired
	    private PricingStrategy peakSeasonPricingStrategy;
	    
	
	@Override
	public Tour getPackageById(Long id) {
			Optional<Tour> page = packageDetailsRepository.findById(id);
			Tour pkg=null;
		    if (page.isPresent()) {
		    	pkg=page.get();
		    } 
		    return pkg;
		}
	
	
	@Override
	public double calculatePrice(long id) {
    	Optional<Tour> page = packageDetailsRepository.findById(id);
		Tour pg=null;
	    if (page.isPresent()) {
	    	pg=page.get();
	    } 
          Tour pkg=pg;  
        double basePrice = pkg.getPriceperperson();
        LocalDate currentDate = LocalDate.now();
        int currentMonth = currentDate.getMonthValue();
        PricingStrategy pricingStrategy;
        if (currentMonth == 6 || currentMonth == 7 || currentMonth == 8) {
            pricingStrategy = peakSeasonPricingStrategy;
            System.out.println("Peak season");
        } else {
            pricingStrategy = offSeasonPricingStrategy;
            System.out.println("offseason");
        }
        return pricingStrategy.calPrice(basePrice);
    }

	}
	  
	
   
	


	
	

