package com.project.tourism.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.project.tourism.model.Tour;
import com.project.tourism.service.AdminPackageService;
@Controller
public class AdminPackageController {
	
	@Autowired
	private AdminPackageService adminPackageService;

	@GetMapping("/listpackages")
	public String viewAllPackages(Model model)
	{
		model.addAttribute("listallpackages",adminPackageService.getAllPackages());
		return "adminlistpacakges";
	}
	
	@GetMapping("/createpackageform")
	public String createpackageform(Model model)
	{
		Tour pkg=new Tour();
		model.addAttribute("pkg", pkg);
		return "newpackage";
	}
	
	@PostMapping("/savePackage")
	public String savePackage(@ModelAttribute("pkg")Tour pkg)
	{
		adminPackageService.savePackage(pkg);
		return "redirect:/listpackages";
	}
	
	@GetMapping("/updatepackageform/{id}")
	public String updatePackageForm(@PathVariable(value="id")long id,Model model)
	{
		
		Tour pkg=adminPackageService.getPackageById(id);
		model.addAttribute("pkg", pkg);
		return "updatepackage";
	}
	
	@GetMapping("/deletepackage/{id}")
	public String  deletePackage(@PathVariable (value ="id")long id)
	{
		this.adminPackageService.deleteUserById(id);
		return "redirect:/listpackages";
	}

}
