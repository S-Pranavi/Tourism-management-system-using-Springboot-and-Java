package com.project.tourism.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.tourism.model.Booking;
import com.project.tourism.model.Itinerary;
import com.project.tourism.model.User;

@Repository
public interface BookingRepository extends JpaRepository<Booking,Long>{
	 List<Booking> findByTourId(Long tourId);
	 List<Booking> findByUserId(Long userId);
}
