package com.project.tourism.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
	@GetMapping("/")
	public String getHomePage() {
		return "homePage";
	}
	
	@GetMapping("/welcome")
	public String getWelcomePage() {
		return "welcomepage";
	}
	
	@GetMapping("/admin")
	public String getAdminPage() {
		return "adminpage";
	}
	
	@GetMapping("/user")
	public String getEmployeePage() {
		return "userpage";
	}
	
	@GetMapping("/accessDenied")
	public String getAccessDeniedPage() {
		return "accessDeniedpage";
	}
	
	
	
}
