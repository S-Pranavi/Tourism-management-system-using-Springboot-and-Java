package com.project.tourism.service;

import java.time.LocalDate;
import java.util.Set;


import org.springframework.stereotype.Component;

@Component("offSeasonPricing")
public class OffSeasonPricing implements PricingStrategy{

private static final Set<Integer> OFF_SEASON_MONTHS = Set.of(1, 2, 9, 10, 11, 12);
    
    @Override
    public double calPrice(double basePrice) {
        LocalDate currentDate = LocalDate.now();
        int currentMonth = currentDate.getMonthValue();
        if (OFF_SEASON_MONTHS.contains(currentMonth)) {
        	System.out.println(currentMonth+"basePrice");
            return basePrice * 0.9; // 10% discount for off-season months
        }
        return basePrice;
    }	

}
