package com.project.tourism.service;

import java.util.List;

import com.project.tourism.model.Tour;

public interface AdminPackageService {
	List<Tour> getAllPackages();
	void savePackage(Tour pkg);
	Tour getPackageById(long id);
	void deleteUserById(long id);
}
