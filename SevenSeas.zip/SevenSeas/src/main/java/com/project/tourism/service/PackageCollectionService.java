package com.project.tourism.service;

import java.util.List;
import java.lang.Iterable;
import com.project.tourism.model.Tour;

public interface PackageCollectionService {
	//List<Package> getAllPackages();
	Iterable<Tour> getAllPackages();
    TourIterable getTourIterable();
    TourIterable getHeritagePackages(String attributeValue); 
    //List<Tour> getHeritagePackages(String type);
    List<Tour> getPiligrimagePackages(String type);
    List<Tour> getWildlifePackages(String type);
    List<Tour> getHillStationPackages(String type);
    List<Tour> getAdventurePackages(String type);
    List<Tour> getBeachPackages(String type);
}
