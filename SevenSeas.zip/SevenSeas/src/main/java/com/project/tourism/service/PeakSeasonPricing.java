package com.project.tourism.service;

import java.time.LocalDate;
import java.util.Set;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
@Component("peakSeasonPricing")
@Primary
public class PeakSeasonPricing implements PricingStrategy{

private static final Set<Integer> PEAK_SEASON_MONTHS = Set.of(6, 7, 8);
    
    @Override
    public double calPrice(double basePrice) {
        LocalDate currentDate = LocalDate.now();
        int currentMonth = currentDate.getMonthValue();
        if (PEAK_SEASON_MONTHS.contains(currentMonth)) {
        	System.out.println(currentMonth+"basePrice");
            return basePrice * 2;
            
        }
        return basePrice;
    }
}
