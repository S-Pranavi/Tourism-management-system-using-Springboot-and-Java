package com.project.tourism;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {
	@GetMapping //http://localhost:8080
	public String get()
	{
		return "this is springboot app";
	}

}
