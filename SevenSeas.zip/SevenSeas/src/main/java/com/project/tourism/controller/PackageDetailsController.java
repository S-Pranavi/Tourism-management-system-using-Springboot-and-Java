package com.project.tourism.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.project.tourism.model.Tour;

import com.project.tourism.service.PackageDetailsService;

@Controller
public class PackageDetailsController {
	
	@Autowired
	private PackageDetailsService packageDetailsService;
	
	@GetMapping("/package-details/{id}")
	public String viewPackageDetails(@PathVariable Long id,Model model)
	{
		double price = packageDetailsService.calculatePrice(id);
		Tour page=packageDetailsService.getPackageById(id);
		model.addAttribute("price",price);
		model.addAttribute("page",page);
		
		return "packagedetails";
	}
}
