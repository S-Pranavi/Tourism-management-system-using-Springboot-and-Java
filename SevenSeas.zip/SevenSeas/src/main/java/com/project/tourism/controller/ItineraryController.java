package com.project.tourism.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.ModelAndView;
import com.project.tourism.model.Itinerary;
import com.project.tourism.model.Tour;
import com.project.tourism.repository.PackageRepository;
import com.project.tourism.service.ItineraryService;
import com.project.tourism.service.PackageDetailsService;

import jakarta.validation.Valid;

@Controller
public class ItineraryController {
	@Autowired
	private final PackageRepository packageRepository;
    private final ItineraryService itineraryService;
    private PackageDetailsService packageService;
    public ItineraryController(PackageRepository packageRepository, ItineraryService itineraryService) {
        this.packageRepository = packageRepository;
        this.itineraryService = itineraryService;
    }

    
  
    @GetMapping("/newitineraryForm/{tourId}")
    public String showAddItineraryForm(@PathVariable Long tourId, Model model) {
        Tour tour = packageRepository.findById(tourId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid tour ID: " + tourId));
        Itinerary itinerary = new Itinerary();
        itinerary.setTour(tour);
        model.addAttribute("itinerary", itinerary);
        model.addAttribute("tour", tour);
        return "newitinerary";
    }
	
    @PostMapping("/saveItinerary")
    public String updateItinerary(@ModelAttribute("itinerary") @Valid Itinerary itinerary) {
        //itinerary.setTour(itinerary.getTour()); // Set the tour object for the itinerary
        itineraryService.saveItinerary(itinerary);
        return "redirect:/listpackages";
    }
	
	 @GetMapping("/tours/{tourId}/itineraries")
	    public ModelAndView getItinerariesByTourId(@PathVariable("tourId") Long tourId) {
	        List<Itinerary> itineraries = itineraryService.getItinerariesByTourId(tourId);
	        ModelAndView mav = new ModelAndView("itineraries");
	        mav.addObject("itineraries", itineraries);
	        return mav;
	    }
	 
	 @GetMapping("/tours/itinerary/{tourId}")
	    public ModelAndView getItineraryByTourId(@PathVariable("tourId") Long tourId) {
	        List<Itinerary> itinerary = itineraryService.getItinerariesByTourId(tourId);
	        ModelAndView mav = new ModelAndView("itinerary");
	        mav.addObject("itinerary", itinerary);
	        return mav;
	    }
	
	 @GetMapping("/itineraries/edit/{id}")
	 public String showEditForm(@PathVariable("id") Long id, Model model) {
	     Itinerary itinerary = itineraryService.getItineraryById(id);
	    // List<Tour> tours = packageRepository.findAll();
	     model.addAttribute("itinerary", itinerary);
	    // model.addAttribute("tours", tours);
	     return "edititinerary";
	 }
	 
	 
	 @GetMapping("/itinerary-details/{itineraryId}")
	    public String getItineraryById(@PathVariable("itineraryId") Long itineraryId, Model model) {
	        Itinerary itinerary = itineraryService.getItineraryById(itineraryId);
	        model.addAttribute("itinerary", itinerary);
	        return "showitinerary";	
	    }

	 
	 @GetMapping("/itineraries/delete/{id}")
	 public String deleteItinerary(@PathVariable("id") Long id,
	                                 RedirectAttributes redirectAttributes) {
	     itineraryService.deleteItinerary(id);
	   // redirectAttributes.addAttribute("tourId", tourId);
	     return "redirect:/listpackages";
	 }
}
