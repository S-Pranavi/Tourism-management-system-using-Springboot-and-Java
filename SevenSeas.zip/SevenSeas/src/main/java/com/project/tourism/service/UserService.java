package com.project.tourism.service;

import com.project.tourism.model.User;

public interface UserService {
	public long saveUser(User user);
}
