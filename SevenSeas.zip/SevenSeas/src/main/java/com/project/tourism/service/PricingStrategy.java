package com.project.tourism.service;

public interface PricingStrategy {
	 public double calPrice(double basePrice);
}
