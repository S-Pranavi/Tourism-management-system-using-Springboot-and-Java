package com.project.tourism.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.tourism.model.Tour;
import com.project.tourism.repository.AdminPackageRepository;


@Service
public class AdminPackageServiceImplementation implements AdminPackageService{
	
	@Autowired
	private AdminPackageRepository adminPackageRepository;

	@Override
	public void savePackage(Tour pkg) {
		this.adminPackageRepository.save(pkg);
		
	}

	@Override
	public List<Tour> getAllPackages() {
		return adminPackageRepository.findAll();
	}

	@Override
	public Tour getPackageById(long id) {
		Optional<Tour> optional=adminPackageRepository.findById(id);
		Tour pkg=null;
		if(optional.isPresent())
		{
			pkg=optional.get();
		}
		else
		{
			throw new RuntimeException("Package not found for id :: "+id);
		}
		return pkg;
	}

	@Override
	public void deleteUserById(long id) {
		this.adminPackageRepository.deleteById(id);	
	}

}
