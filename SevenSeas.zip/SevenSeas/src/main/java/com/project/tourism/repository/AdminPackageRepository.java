package com.project.tourism.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.project.tourism.model.Tour;

@Repository
public interface AdminPackageRepository extends JpaRepository<Tour,Long> {
	
}
