package com.project.tourism.service;

import java.util.Iterator;

import com.project.tourism.model.Tour;

public class TourIteratorImpl implements TourIterator {
    private final Iterator<Tour> tourIterator;

    public TourIteratorImpl(Iterable<Tour> tours) {
        this.tourIterator = tours.iterator();
    }

    @Override
    public boolean hasNext() {
        return tourIterator.hasNext();
    }

    @Override
    public Tour next() {
        return tourIterator.next();
    }
}
