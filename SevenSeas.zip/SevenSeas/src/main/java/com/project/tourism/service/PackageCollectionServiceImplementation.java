package com.project.tourism.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.tourism.model.Tour;
import com.project.tourism.repository.PackageRepository;


@Service
public class PackageCollectionServiceImplementation implements PackageCollectionService{

	@Autowired
	private PackageRepository packageCollectionRepository;
	/*@Override
	public List<Package> getAllPackages() {
		return packageCollectionRepository.findAll();	
	}*/
	public PackageCollectionServiceImplementation(PackageRepository packageCollectionRepository) {
        this.packageCollectionRepository=packageCollectionRepository;
    }
	 public Iterable<Tour> getAllPackages() {
	                return packageCollectionRepository.findAll();
	            
	        }
	    

	

	@Override
	public List<Tour> getPiligrimagePackages(String type) {
		return packageCollectionRepository.findByType("Piligrimage");
	}

	@Override
	public List<Tour> getWildlifePackages(String type) {
		return packageCollectionRepository.findByType("Wildlife");
	}

	@Override
	public List<Tour> getHillStationPackages(String type) {
		return packageCollectionRepository.findByType("Hill station");
	}

	@Override
	public List<Tour> getAdventurePackages(String type) {
		return packageCollectionRepository.findByType("Adventure");
	}

	@Override
	public List<Tour> getBeachPackages(String type) {
		return packageCollectionRepository.findByType("Beach");
	}

	
	@Override
	public TourIterable getHeritagePackages(String type) {
        return new TouriterableImp(packageCollectionRepository.findByType("Heritage"));

	}

	@Override
	public TourIterable getTourIterable() {
        return new TouriterableImp(getAllPackages());

	}
}
	
	

