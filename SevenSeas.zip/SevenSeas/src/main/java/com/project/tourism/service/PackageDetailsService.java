package com.project.tourism.service;

import com.project.tourism.model.Tour;
public interface PackageDetailsService {
	public double calculatePrice(long id);
	Tour getPackageById(Long id);
}
