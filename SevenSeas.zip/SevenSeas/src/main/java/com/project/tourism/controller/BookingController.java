package com.project.tourism.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.project.tourism.model.Booking;
import com.project.tourism.repository.BookingRepository;
import com.project.tourism.repository.PackageRepository;
import com.project.tourism.repository.UserRepository;
import com.project.tourism.service.BookingService;

import ch.qos.logback.core.model.Model;

@Controller
public class BookingController {

	@Autowired
	private BookingService bookingService;
	private PackageRepository packageRepository;
	private UserRepository userRepository;
	
	@GetMapping("/listbookings")
	    public String getAllBookings(Model model) {
	        List<Booking> bookings = bookingService.getAllBookings();
	        model.addAttribute("bookings", bookings);
	        return "booking-list";
	    }
	
}
