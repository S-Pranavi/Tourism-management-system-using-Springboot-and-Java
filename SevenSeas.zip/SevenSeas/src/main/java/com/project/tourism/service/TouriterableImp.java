package com.project.tourism.service;

import com.project.tourism.model.Tour;

public class TouriterableImp implements TourIterable {
    private final Iterable<Tour> tours;

    public TouriterableImp(Iterable<Tour> tours) {
        this.tours = tours;
    }

    @Override
    public TourIterator iterator() {
        return new TourIteratorImpl(tours);
    }
}

