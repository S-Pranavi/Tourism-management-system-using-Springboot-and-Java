package com.project.tourism.service;

import java.util.List;

import com.project.tourism.model.Booking;
import com.project.tourism.model.Itinerary;



public interface BookingService  {
	List<Booking> getAllBookings();
	List<Booking> getBookingsByTourId(Long tourId);
	List<Booking> getBookingsByUserId(Long userId);
	void saveBooking(Booking bk);
	Booking getBookingById(long id);
	void deleteBookingById(long id);
}
