package com.project.tourism.service;

import java.util.List;

import com.project.tourism.model.Itinerary;

public interface ItineraryService {
	Itinerary getItineraryById(Long itineraryId);
	List<Itinerary> getItinerariesByTourId(Long tourId);
    void saveItinerary(Itinerary itinerary);
    void deleteItinerary(Long itineraryId);
    
}
