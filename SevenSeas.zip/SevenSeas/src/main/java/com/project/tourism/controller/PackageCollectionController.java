package com.project.tourism.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.lang.Iterable;

import com.project.tourism.model.Tour;
import com.project.tourism.service.PackageCollectionService;
import com.project.tourism.service.TourIterable;
import com.project.tourism.service.TourIterator;
@Controller
public class PackageCollectionController {
//display packages
	
	@Autowired
	private PackageCollectionService packageCollectionService;
	
	
	/*public String viewPackages(Model model)
	{
		model.addAttribute("listPackages",packageCollectionService.getAllPackages());
		return "viewpackages";
	}*/
	@GetMapping("/packages")
	public String  getAllPackages(Model model) {
		Iterable<Tour> tours = packageCollectionService.getAllPackages();
        model.addAttribute("tours", tours);
        return "packages";
       
    }
	/*
	@GetMapping("/packages")
	public String getAllPackages(Model model) {
	    Iterable<Tour> tours =packageCollectionService.getAllPackages();
	    TourIterable tourIterable = new TourIterable(tours);
	    model.addAttribute("tours", tourIterable);
	    return "packages";
	}*/

	
	@GetMapping("/packages/{attributeValue}")
    public String viewHeritagePackages(@PathVariable String attributeValue,Model model) {
        TourIterable tourIterable = packageCollectionService.getHeritagePackages(attributeValue);
		model.addAttribute("listHeritagePackages", tourIterable);
		return "heritagepackages";
	}
	
	@GetMapping("/packages/piligrimage-packages")
    public String viewPiligrimagePackages(Model model) {
		model.addAttribute("listPiligrimagePackages", packageCollectionService.getPiligrimagePackages("Piligrimage"));
		return "piligrimagepackages";
	}
	
	@GetMapping("/packages/wildlife-packages")
    public String viewWildlifePackages(Model model) {
		model.addAttribute("listWildlifePackages", packageCollectionService.getWildlifePackages("Piligrimage"));
		return "wildlifepackages";
	}
	
	@GetMapping("/packages/hillstation-packages")
    public String hillstationPackages(Model model) {
		model.addAttribute("listHillStationPackages", packageCollectionService.getHillStationPackages("Hill station"));
		return "hillstationpackages";
	}
	
	@GetMapping("/packages/beach-packages")
    public String viewBeachPackages(Model model) {
		model.addAttribute("listBeachPackages", packageCollectionService.getBeachPackages("Beach"));
		return "beachpackages";
	}
	
	@GetMapping("/packages/adventure-packages")
    public String viewadventurePackages(Model model) {
		model.addAttribute("listAdventurePackages", packageCollectionService.getAdventurePackages("Adventure"));
		return "adventurepackages";
	}
}
