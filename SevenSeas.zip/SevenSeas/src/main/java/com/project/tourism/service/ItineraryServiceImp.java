package com.project.tourism.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.tourism.model.Itinerary;
import com.project.tourism.model.Tour;
import com.project.tourism.repository.ItineraryRepository;
@Service
public class ItineraryServiceImp implements ItineraryService{

	@Autowired
    private final ItineraryRepository itineraryRepository;
	
	public ItineraryServiceImp(ItineraryRepository itineraryRepository) {
        this.itineraryRepository = itineraryRepository;
    }

	@Override
	public List<Itinerary> getItinerariesByTourId(Long tourId) {
        return itineraryRepository.findByTourId(tourId);

	}

	@Override
	public void saveItinerary(Itinerary itinerary) {
		itineraryRepository.save(itinerary);
		
	}

	@Override
	public void deleteItinerary(Long itineraryId) {
		 itineraryRepository.deleteById(itineraryId);
		
	}

	@Override
	public Itinerary getItineraryById(Long itineraryId) {
		Optional<Itinerary> optional=itineraryRepository.findById(itineraryId);
		Itinerary itinerary=null;
		if(optional.isPresent())
		{
			itinerary=optional.get();
		}
		else
		{
			throw new RuntimeException("Package not found for id :: "+itineraryId);
		}
		return itinerary;
	            
	}

	
	
}
