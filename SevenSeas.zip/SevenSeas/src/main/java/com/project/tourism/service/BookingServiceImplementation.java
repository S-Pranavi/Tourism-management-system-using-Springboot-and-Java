package com.project.tourism.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.tourism.model.Booking;
import com.project.tourism.model.Tour;
import com.project.tourism.repository.AdminPackageRepository;
import com.project.tourism.repository.BookingRepository;

@Service
public class BookingServiceImplementation implements BookingService{

	@Autowired
	private BookingRepository bookingRepository;
	
	@Override
	public List<Booking> getAllBookings() {
		return bookingRepository.findAll();
	}

	@Override
	public void saveBooking(Booking bk) {
		this.bookingRepository.save(bk);
		
	}

	@Override
	public Booking getBookingById(long id) {
		Optional<Booking> optional=bookingRepository.findById(id);
		Booking bk=null;
		if(optional.isPresent())
		{
			bk=optional.get();
		}
		else
		{
			throw new RuntimeException("Booking not found for id :: "+id);
		}
		return bk;
	}

	@Override
	public void deleteBookingById(long id) {
		this.bookingRepository.deleteById(id);
		
	}

	@Override
	public List<Booking> getBookingsByTourId(Long tourId) {
		return bookingRepository.findByTourId(tourId);
	}

	@Override
	public List<Booking> getBookingsByUserId(Long userId) {
		return bookingRepository.findByUserId(userId);
	}

}
