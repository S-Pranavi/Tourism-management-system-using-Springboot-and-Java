package com.project.tourism.service;

import java.util.Iterator;

import com.project.tourism.model.Tour;

public interface TourIterable extends Iterable<Tour> {
    @Override
    TourIterator iterator();
}
