package com.project.tourism.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.tourism.model.Tour;

@Repository
public interface PackageRepository extends JpaRepository<Tour,Long>{
	List<Tour> findByType(String type);
	

}
