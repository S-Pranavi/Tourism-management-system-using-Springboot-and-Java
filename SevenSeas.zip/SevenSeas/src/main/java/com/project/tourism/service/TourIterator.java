package com.project.tourism.service;

import java.util.Iterator;
import com.project.tourism.model.Tour;

public interface TourIterator extends Iterator<Tour> {
    @Override
    boolean hasNext();
    @Override
    Tour next();
}

