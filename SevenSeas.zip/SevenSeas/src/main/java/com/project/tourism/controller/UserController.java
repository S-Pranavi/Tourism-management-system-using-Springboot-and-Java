package com.project.tourism.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.project.tourism.model.User;
import com.project.tourism.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {
	@Autowired
	private  UserService userService;


	@GetMapping("/showNewUserForm")
	public String showNewUserForm(Model model)
	{
		//create model attribute to bind form data
		User user=new User();
		model.addAttribute("user", user);
		return "userregister";
	}
	
	@PostMapping("/saveUser")
	public String saveUser(
			@ModelAttribute User user,
			Model model
			) 
	{
	
		long id = userService.saveUser(user);
		String message = "User '"+id+"' saved successfully !";
		model.addAttribute("msg", message);
		return "userregister";
	}
	
	
}
